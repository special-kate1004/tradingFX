<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>StockPulseFX - Advanced Trading Platform</title>
    <meta name="description" content="Professional trading platform with access to NSE, MCX, Forex, US Stocks, Cryptos, and global markets. Trade smarter with advanced analytics." />
    <meta name="author" content="Lovable" />

    <meta property="og:title" content="StockPulseFX - Advanced Trading Platform" />
    <meta property="og:description" content="Professional trading platform with access to global markets. Trade NSE, MCX, Forex, US Stocks, Cryptos and more." />
    <meta property="og:type" content="website" />
    <meta property="og:image" content="https://lovable.dev/opengraph-image-p98pqg.png" />

    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@lovable_dev" />
    <meta name="twitter:image" content="https://lovable.dev/opengraph-image-p98pqg.png" />
    <script type="module" crossorigin src="/assets/index-B1KGZ00m.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/index-BfYkFucf.css">
  </head>

  <body class="dark">
    <div id="root"></div>
  </body>
</html>
