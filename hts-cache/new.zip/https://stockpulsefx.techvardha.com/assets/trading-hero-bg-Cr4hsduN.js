const a="/assets/images/trading-hero-bg.jpg";export{a as m};
